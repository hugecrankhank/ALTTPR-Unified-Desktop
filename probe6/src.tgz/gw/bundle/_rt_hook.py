import os
import sys

sys.path.append(os.path.join(sys._MEIPASS, "ext"))
