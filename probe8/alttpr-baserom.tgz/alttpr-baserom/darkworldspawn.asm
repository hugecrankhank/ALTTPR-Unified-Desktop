;================================================================================
; Dark World Spawn Location Fix & Master Sword Grove Fix
;--------------------------------------------------------------------------------
DarkWorldSaveFix:
	JSL MasterSwordFollowerClear
	JML StatSaveCounter
;--------------------------------------------------------------------------------
DoWorldFix:
	LDA.l InvertedMode : BEQ +
		JMP DoWorldFix_Inverted
	+
	LDA.l Bugfix_MirrorlessSQToLW : BEQ .skip_mirror_check
		LDA.l FollowerIndicator : CMP.b #$04 : BNE + ; if old man following, skip mirror/aga check
		LDA.l FollowerTravelAllowed : CMP.b #$02 : BEQ +
			LDA.l OldManRetrievalWorld
			BRA .noMirror
		+ LDA.l MirrorEquipment : AND.b #$02 : BEQ .noMirror ; check if we have the mirror
	.skip_mirror_check ; alt entrance point
	LDA.l ProgressIndicator : CMP.b #$03 : BCS .done ; check if agahnim 1 is alive
	.setLightWorld
	LDA.b #$00
	.noMirror
	STA.l CurrentWorld ; set flag to light world
	LDA.l SmithDeleteOnSave : BEQ .transform
		LDA.l FollowerIndicator
		CMP.b #$07 : BEQ .clear ; clear frog
		CMP.b #$08 : BEQ .clear ; clear dwarf - consider flute implications
		BRA .done
		.clear
		LDA.b #$00 : STA.l FollowerIndicator : BRA .done ; clear follower
	.transform
	LDA.l FollowerIndicator : CMP.b #$07 : BNE .done : INC : STA.l FollowerIndicator ; convert frog to dwarf
	.done
RTL
;--------------------------------------------------------------------------------
SetDeathWorldChecked:
	LDA.l InvertedMode : BEQ +
		JMP SetDeathWorldChecked_Inverted
	+
	LDA.b IndoorsFlag : BEQ .outdoors
		LDA.w DungeonID : CMP.b #$FF : BNE .dungeon
		LDA.b RoomIndex : ORA.b RoomIndex+1 : BNE ++
			LDA.l GanonPyramidRespawn : BNE .pyramid ; if flag is set, force respawn at pyramid on death to ganon
	++
	.outdoors
JMP DoWorldFix

	.dungeon
	LDA.l MosaicLevel : BNE .dontfix ; this is a sanc & quit
	LDA.l Bugfix_PreAgaDWDungeonDeathToFakeDW : BNE .done ; if the bugfix is enabled, we do nothing on death in dungeon
	.dontfix
	JMP DoWorldFix_skip_mirror_check

	.pyramid
	LDA.b #$40 : STA.l CurrentWorld ; set flag to dark world
	LDA.l FollowerIndicator : CMP.b #$08 : BNE .done : DEC : STA.l FollowerIndicator : + ; convert dwarf to frog
	.done
RTL
;================================================================================
DoWorldFix_Inverted:
	LDA.l Bugfix_MirrorlessSQToLW : BEQ .skip_mirror_check
		LDA.l FollowerIndicator : CMP.b #$04 : BNE + ; if old man following, skip mirror/aga check
		LDA.l FollowerTravelAllowed : CMP.b #$02 : BEQ +
			LDA.l OldManRetrievalWorld
			BRA .setWorld
	    + LDA.l MirrorEquipment : AND.b #$02 : BEQ .noMirror ; check if we have the mirror
	.skip_mirror_check ; alt entrance point
	LDA.l ProgressIndicator : CMP.b #$03 : BCS .done ; check if agahnim 1 is alive
	.noMirror
	.setDarkWorld
	LDA.b #$40
	.setWorld
	STA.l CurrentWorld ; set flag to dark world
	LDA.l SmithDeleteOnSave : BEQ .transform
		LDA.l FollowerIndicator
		CMP.b #$07 : BEQ .clear ; clear frog
		CMP.b #$08 : BEQ .clear ; clear dwarf - consider flute implications
		BRA .done
		.clear
		LDA.b #$00 : STA.l FollowerIndicator : BRA .done ; clear follower
	.transform
	LDA.l FollowerIndicator : CMP.b #$07 : BNE .done : INC : STA.l FollowerIndicator ; convert frog to dwarf
	.done
RTL
;--------------------------------------------------------------------------------
SetDeathWorldChecked_Inverted:
	LDA.b IndoorsFlag : BEQ .outdoors
		LDA.w DungeonID : CMP.b #$FF : BNE .dungeon
		LDA.b RoomIndex : ORA.b RoomIndex+1 : BNE ++
			LDA.l GanonPyramidRespawn : BNE .castle ; if flag is set, force respawn at pyramid on death to ganon
		++
	.outdoors
JMP DoWorldFix_Inverted

	.dungeon
	LDA.l MosaicLevel : BNE .dontfix ; this is a sanc & quit
	LDA.l Bugfix_PreAgaDWDungeonDeathToFakeDW : BNE .done ; if the bugfix is enabled, we do nothing on death in dungeon
  .dontfix
	JMP DoWorldFix_Inverted_skip_mirror_check

	.castle
	LDA.b #$00 : STA.l CurrentWorld ; set flag to dark world
	LDA.l FollowerIndicator : CMP.b #$07 : BNE + : LDA.b #$08 : STA.l FollowerIndicator : + ; convert frog to dwarf
	.done
RTL
;================================================================================


;--------------------------------------------------------------------------------
FakeWorldFix:
	LDA.l FixFakeWorld : BEQ +
		PHX
			LDX.b OverworldIndex : LDA.l OWTileWorldAssoc, X : STA.l CurrentWorld
		PLX
	+
RTL
;--------------------------------------------------------------------------------
GetCurrentWorldForLoad:
LDA.l FollowerTravelAllowed : CMP.b #$02 : BEQ .default
LDA.l FollowerIndicator : CMP.b #$04 : BNE .default
	LDA.l InvertedMode : BEQ +
		LDA.b #$40
	+ RTL
.default
LDA.l CurrentWorld
RTL 
;--------------------------------------------------------------------------------
MasterSwordFollowerClear:
	LDA.l FollowerIndicator
	CMP.b #$0E : BNE .exit ; clear master sword follower
	LDA.b #$00 : STA.l FollowerIndicator ; clear follower
.exit
	RTL
;--------------------------------------------------------------------------------
FixAgahnimFollowers:
	LDA.l FollowerTravelAllowed : CMP.b #$02 : BEQ +
		LDA.b #$00 : STA.l FollowerIndicator ; clear follower
	+
	JML PrepDungeonExit ; thing we wrote over

;--------------------------------------------------------------------------------
macro SetMinimum(base,filler,compare)
	LDA.l <compare> : !SUB.l <base> : !BLT ?done
		STA.l <filler>
	?done:
endmacro
RefreshRainAmmo:
	LDA.l ProgressIndicator : CMP.b #$01 : BEQ .rain ; check if we're in rain state
RTL
.rain
	LDA.l StartingEntrance : BEQ .uncle
	CMP.b #$03 : BNE + ; Uncle
		.uncle
		LDA.l RainDeathRefillMagic_Uncle : JSR .refillMagic
		LDA.l RainDeathRefillBombs_Uncle : JSR .refillBombs
		LDA.l ArrowMode : BNE .rupeeBow
		LDA.l RainDeathRefillArrows_Uncle : JSR .refillArrows
		BRA .done
	+ CMP.b #$02 : BNE + ; Cell
		LDA.l RainDeathRefillMagic_Cell : JSR .refillMagic
		LDA.l RainDeathRefillBombs_Cell : JSR .refillBombs
		LDA.l ArrowMode : BNE .rupeeBow
		LDA.l RainDeathRefillArrows_Cell : JSR .refillArrows
		BRA .done
	+ CMP.b #$04 : BNE + ; Mantle
		LDA.l RainDeathRefillMagic_Mantle : JSR .refillMagic
		LDA.l RainDeathRefillBombs_Mantle : JSR .refillBombs
		LDA.l ArrowMode : BNE .rupeeBow
		LDA.l RainDeathRefillArrows_Mantle : JSR .refillArrows
		BRA .done
	+ BRA .done

	.rupeeBow
		REP #$20
		LDA.l RainDeathRefillRupeeBow : JSR .refillRupees
		SEP #$20

.done
RTL

.refillMagic
	SEC : SBC.l CurrentMagic : BCC +
		STA.l MagicFiller
	+ RTS

.refillBombs
	SEC : SBC.l BombsEquipment : BCC +
		STA.l BombsFiller
	+ RTS

.refillArrows
	SEC : SBC.l CurrentArrows : BCC +
		STA.l ArrowsFiller
	+ RTS

.refillRupees
	CMP.l CurrentRupees : BCC +
		STA.l CurrentRupees
	+ RTS
;--------------------------------------------------------------------------------
SetEscapeAssist:
	LDA.l ProgressIndicator : CMP.b #$01 : BNE .no_train ; check if we're in rain state
	.rain
		LDA.l EscapeAssist
		BIT.b #$04 : BEQ + : STA.l InfiniteArrows : +
		BIT.b #$02 : BEQ + : STA.l InfiniteBombs : +
		BIT.b #$01 : BEQ + : STA.l InfiniteArrows : +
		BRA ++
	.no_train ; choo choo
		LDA.l EscapeAssist : BIT.b #$04 : BEQ + : LDA.b #$00 : STA.l InfiniteMagic : +
		LDA.l EscapeAssist : BIT.b #$02 : BEQ + : LDA.b #$00 : STA.l InfiniteBombs : +
		LDA.l EscapeAssist : BIT.b #$01 : BEQ + : LDA.b #$00 : STA.l InfiniteArrows : +
	++
RTL
;--------------------------------------------------------------------------------
SetSilverBowMode:
	LDA.l SilverArrowsUseRestriction : BEQ + ; fix bow type for restricted arrow mode
		LDA.l BowEquipment : CMP.b #$3 : BCC +
		SBC.b #$02 : STA.l BowEquipment
	+
RTL
;================================================================================
