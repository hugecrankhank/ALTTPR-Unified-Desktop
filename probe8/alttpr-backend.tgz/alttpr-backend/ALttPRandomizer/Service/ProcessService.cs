﻿namespace ALttPRandomizer.Service {
    using System.Diagnostics;
    using System.Linq;
    using Microsoft.Extensions.Logging;

    public class ProcessService {
        public ProcessService(ILogger<ProcessService> logger) {
            this.Logger = logger;
        }

        public ILogger<ProcessService> Logger { get; }

        public Process StartProcess(string seedId, string workingDirectory, params string[] args) {
            var start = new ProcessStartInfo(args[0], args.Skip(1)) {
                WorkingDirectory = workingDirectory,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            };

            this.Logger.LogInformation("{ProcessId} - executing command: {Command}", seedId, string.Join(" ", args.Select(arg => arg.Contains(' ') ? $"\"{arg}\"" : arg)));

            var process = Process.Start(start) ?? throw new GenerationFailedException("{0} - Process failed to start.", seedId);
            process.EnableRaisingEvents = true;

            process.OutputDataReceived += (_, args) => {
                if (args.Data != null) {
                    Logger.LogInformation("{ProcessId} - {Stream}: {Output}", seedId, "STDOUT", args.Data);
                }
            };
            process.ErrorDataReceived += (_, args) => {
                if (args.Data != null) {
                    Logger.LogInformation("{ProcessId} - {Stream}: {Output}", seedId, "STDERR", args.Data);
                }
            };

            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            return process;
        }
    }
}
