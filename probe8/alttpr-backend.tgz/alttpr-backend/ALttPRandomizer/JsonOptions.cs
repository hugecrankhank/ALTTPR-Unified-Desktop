﻿namespace ALttPRandomizer {
    using System.Text.Json;
    using System.Text.Json.Serialization;
    using ALttPRandomizer.Serialization;

    public static class JsonOptions {
        public static readonly JsonSerializerOptions Default = new JsonSerializerOptions(JsonSerializerDefaults.Web) {
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
            NumberHandling = JsonNumberHandling.Strict,
        }.WithStringEnum();

        public static JsonSerializerOptions WithStringEnum(this JsonSerializerOptions options) {
            options.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.SnakeCaseLower, false));
            options.Converters.Add(new RandomizableWeightsJsonConverter());
            return options;
        }
    }
}
