﻿namespace ALttPRandomizer.Model {
    using System;
    using System.Text.Json;
    using System.Text.Json.Nodes;
    using Microsoft.OpenApi;
    using Swashbuckle.AspNetCore.SwaggerGen;
    using YamlDotNet.Serialization;

    public class MysterySettings {
        public RandomizableWeights<Mode> Mode { get; set; } = new();

        public RandomizableWeights<Weapons> Weapons { get; set; } = new();

        public RandomizableWeights<Goal> Goal { get; set; } = new();

        public RandomizableWeights<EntryRequirement> CrystalsGanon { get; set; } = new();

        public RandomizableWeights<BossRequirement> BossesGanon { get; set; } = new();

        public RandomizableWeights<TriforceRequirement> TriforcePieces { get; set; } = new();

        [YamlMember(Alias = "crystals_gt")]
        public RandomizableWeights<EntryRequirement> CrystalsGT { get; set; } = new();

        public RandomizableWeights<GanonItem> GanonItem { get; set; } = new();

        public RandomizableWeights<EntranceShuffle> EntranceShuffle { get; set; } = new();

        public RandomizableWeights<OverworldMapDungeons> OverworldMapDungeons { get; set; } = new();

        public RandomizableWeights<LinksHouse> LinksHouse { get; set; } = new();

        public RandomizableWeights<SkullWoodsShuffle> SkullWoods { get; set; } = new();

        public RandomizableWeights<LinkedDrops> LinkedDrops { get; set; } = new();

        public RandomizableWeights<BossShuffle> BossShuffle { get; set; } = new();

        public RandomizableWeights<EnemyShuffle> EnemyShuffle { get; set; } = new();

        public RandomizableWeights<DamageTableShuffle> DamageTableShuffle { get; set; } = new();

        public RandomizableWeights<KeyLocations> SmallKeys { get; set; } = new();

        public RandomizableWeights<DungeonItemLocations> BigKeys { get; set; } = new();

        public RandomizableWeights<DungeonItemLocations> Maps { get; set; } = new();

        public RandomizableWeights<DungeonItemLocations> Compasses { get; set; } = new();

        public RandomizableWeights<ShowLootMap> ShowLootMap { get; set; } = new();

        public RandomizableWeights<ShowLootHud> ShowLootHud { get; set; } = new();

        public RandomizableWeights<ShowMap> ShowMap { get; set; } = new();

        public RandomizableWeights<ShopShuffle> ShopShuffle { get; set; } = new();

        public RandomizableWeights<DropShuffle> DropShuffle { get; set; } = new();

        public RandomizableWeights<PotShuffle> PotShuffle { get; set; } = new();

        public RandomizableWeights<PrizeShuffle> PrizeShuffle { get; set; } = new();

        public RandomizableWeights<BootsSettings> Boots { get; set; } = new();

        public RandomizableWeights<FluteSettings> Flute { get; set; } = new();

        public RandomizableWeights<DarkRoomSettings> DarkRooms { get; set; } = new();

        public RandomizableWeights<BombSettings> Bombs { get; set; } = new();

        public RandomizableWeights<BookSettings> Book { get; set; } = new();

        public RandomizableWeights<MirrorSettings> Mirror { get; set; } = new();

        public RandomizableWeights<DoorShuffle> DoorShuffle { get; set; } = new();

        public RandomizableWeights<DoorLobbies> Lobbies { get; set; } = new();

        public RandomizableWeights<DoorTypeMode> DoorTypeMode { get; set; } = new();

        public RandomizableWeights<TrapDoorMode> TrapDoorMode { get; set; } = new();

        public RandomizableWeights<ExtraKeysMode> ExtraKeys { get; set; } = new();

        public RandomizableWeights<FollowerShuffle> FollowerShuffle { get; set; } = new();

        public RandomizableWeights<FluteShuffle> FluteShuffle { get; set; } = new();

        public RandomizableWeights<OverworldLayout> OverworldLayout { get; set; } = new();

        public RandomizableWeights<OverworldWorldLayouts> OverworldWorldLayouts { get; set; } = new();

        public RandomizableWeights<OverworldLayoutTerrain> OverworldLayoutTerrain { get; set; } = new();

        public RandomizableWeights<OverworldLayoutEdges> OverworldLayoutEdges { get; set; } = new();

        public RandomizableWeights<OverworldMapFog> OverworldMapFog { get; set; } = new();

        public RandomizableWeights<TileSwap> TileSwap { get; set; } = new();

        public RandomizableWeights<DamageChallengeMode> DamageChallenge { get; set; } = new();

        public RandomizableWeights<Hints> Hints { get; set; } = new();
    }

    public class DefaultMysterySettingsFilter : IOperationFilter {
        private readonly MysterySettings exampleMystery;
        private readonly JsonNode? exampleMysteryJson;

        public DefaultMysterySettingsFilter() {
            this.exampleMystery = new MysterySettings();

            var mysteryFields = typeof(MysterySettings).GetProperties();

            foreach (var field in mysteryFields) {
                var type = field.PropertyType;

                if (!type.IsGenericType || type.GetGenericTypeDefinition() != typeof(RandomizableWeights<>)) {
                    continue;
                }

                Type itemType = type.GetGenericArguments()[0];
                Type innerType = typeof(RandomizableWeights<>).MakeGenericType(itemType)!;

                var weights = innerType.GetProperty("EqualAll")?.GetValue(null);

                if (weights != null) {
                    field.SetValue(this.exampleMystery, weights);
                }
            }

            this.exampleMysteryJson = JsonSerializer.SerializeToNode(this.exampleMystery, JsonOptions.Default);
        }

        public void Apply(OpenApiOperation operation, OperationFilterContext context) {
            foreach (var description in context.ApiDescription.ParameterDescriptions) {
                if (description.Type != typeof(MysterySettings)) {
                    continue;
                }

                if (description.Source.Id == "Body") {
                    if (operation.RequestBody != null && operation.RequestBody.Content != null) {
                        foreach ((_, var value) in operation.RequestBody.Content) {
                            value.Example = this.exampleMysteryJson;
                        }
                    }
                }
            }
        }
    }
}
