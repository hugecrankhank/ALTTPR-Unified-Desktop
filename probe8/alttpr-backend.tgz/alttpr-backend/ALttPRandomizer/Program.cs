﻿namespace ALttPRandomizer {
    using ALttPRandomizer.Azure;
    using ALttPRandomizer.Serialization;
    using ALttPRandomizer.Model;
    using ALttPRandomizer.Options;
    using ALttPRandomizer.Randomizers;
    using ALttPRandomizer.Service;
    using ALttPRandomizer.Settings;
    using global::Azure.Core;
    using global::Azure.Identity;
    using global::Azure.Monitor.OpenTelemetry.AspNetCore;
    using global::Azure.Storage.Blobs;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using OpenTelemetry.Metrics;
    using Serilog;
    using System;
    using System.Diagnostics.Metrics;
    using System.Linq;
    using System.Text.Json;
    using YamlDotNet.Serialization;
    using YamlDotNet.Serialization.NamingConventions;

    internal class Program {
        static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Configuration
                .AddJsonFile("appsettings.json")
                .AddJsonFile("appsettings.Development.json", true)
                .AddEnvironmentVariables();

            builder.Services.Configure<ServiceOptions>(builder.Configuration.GetSection("ALttPRandomizer"));

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(builder.Configuration)
                .CreateLogger();

            builder.Services.AddLogging(logger => {
                logger.ClearProviders();
                logger.AddSerilog();
            });

            var provider = builder.Services.BuildServiceProvider();
            var settings = provider.GetRequiredService<IOptionsMonitor<ServiceOptions>>().CurrentValue!;

            var allowedCors = settings.AllowedCors;
            var envCors = Environment.GetEnvironmentVariable("ALLOWED_CORS");
            if (envCors != null) {
                allowedCors = allowedCors.Concat(envCors.Split()).ToList();
            }

            builder.Services.AddCors(options => {
                options.AddPolicy("AllowDomains", policy => {
                    policy.WithOrigins(allowedCors.ToArray()).AllowAnyMethod().AllowAnyHeader();
                });
            });

            var yamlDeserializer =
                new DeserializerBuilder()
                    .WithNamingConvention(UnderscoredNamingConvention.Instance)
                    .WithTypeConverter(new YamlStringEnumConverter())
                    .WithTypeConverter(new RandomizableWeightsYamlConverters())
                    .Build();

            var yamlFormatter =
                new YamlInputFormatter(
                    yamlDeserializer,
                    provider.GetRequiredService<ILogger<YamlInputFormatter>>());

            builder.Services
                .AddControllers(options => {
                    options.InputFormatters.Add(yamlFormatter);
                })
                .AddJsonOptions(x => {
                    x.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
                    x.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower;
                    x.JsonSerializerOptions.WithStringEnum();
                });
            builder.Services.AddSwaggerGen(options => {
                options.OperationFilter<DefaultMysterySettingsFilter>();
            });

            TokenCredential? token = null;

            if (Environment.GetEnvironmentVariable("USE_SAMI") == "true") {
                token = new ManagedIdentityCredential(ManagedIdentityId.SystemAssigned);
            } else {
                var options = new DefaultAzureCredentialOptions();

                var clientId = Environment.GetEnvironmentVariable("CLIENT_ID");

                if (clientId != null) {
                    options.ManagedIdentityClientId = new(clientId);
                }

                token = new DefaultAzureCredential(options);
            }

            builder.Services.ConfigureOpenTelemetryMeterProvider((sp, builder) => builder.AddMeter("ALttPRandomizer"));
            builder.Services.AddSingleton<Meter>(new Meter("ALttPRandomizer"));

            var seedClient = new BlobContainerClient(settings.AzureSettings.BlobstoreEndpoint, token);

            builder.Services.AddSingleton(seedClient);
            builder.Services.AddSingleton(sp => sp);
            builder.Services.AddSingleton<AzureStorage>();
            builder.Services.AddSingleton<CommonSettingsProcessor>();
            builder.Services.AddSingleton<ProcessService>();
            builder.Services.AddSingleton<ShutdownHandler>();

            builder.Services.AddScoped<BaseRandomizer>();
            builder.Services.AddScoped<MysteryRandomizer>();
            builder.Services.AddScoped<RandomizeService>();
            builder.Services.AddScoped<SeedService>();
            builder.Services.AddScoped<IdGenerator>();

            builder.Services.AddOpenTelemetry().UseAzureMonitor();

            var app = builder.Build();

            app.UseHttpsRedirection();
            app.UseCors("AllowDomains");
            app.MapControllers();
            app.UseSwagger();
            app.UseSwaggerUI(c => {
                c.ShowCommonExtensions();
                c.EnableValidator();
            });

            var sh = app.Services.GetService<ShutdownHandler>();

            try {
                app.Run();
            } catch (Exception ex) {
                Log.Fatal(ex, "Fatal error running application");
            } finally {
                try {
                    sh?.HandleShutdown().Wait();
                } catch (Exception ex) {
                    Log.Fatal(ex, "Fatal error handling shutdown");
                } finally {
                    Log.CloseAndFlush();
                }
            }
        }
    }
}
