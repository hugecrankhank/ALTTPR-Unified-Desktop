﻿namespace ALttPRandomizer.Randomizers {
    using System;
    using System.Linq;
    using ALttPRandomizer.Model;

    public class MysteryRandomizer {
        public SeedSettings Roll(MysterySettings mystery, SeedSettings initialSettings) {
            var mysteryFields = typeof(MysterySettings).GetProperties();
            var settingsFields =
                typeof(SeedSettings).GetProperties()
                    .ToDictionary(field => field.Name, field => field);

            foreach (var field in mysteryFields) {
                if (!settingsFields.ContainsKey(field.Name)) {
                    continue;
                }

                var value = field.GetValue(mystery);

                if (value is IRandomizableWeights weights && !weights.IsEmpty) {
                    settingsFields[field.Name].SetValue(initialSettings, weights.Roll());
                }
            }

            return initialSettings;
        }
    }
}
