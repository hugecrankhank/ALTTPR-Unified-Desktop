﻿namespace ALttPRandomizer {
    using ALttPRandomizer.Model;
    using ALttPRandomizer.Service;
    using ALttPRandomizer.Settings;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class SeedController : Controller {
        public SeedController(
                RandomizeService randomizeService,
                SeedService seedService,
                ILogger<SeedController> logger) {
            this.RandomizeService = randomizeService;
            this.SeedService = seedService;
            this.Logger = logger;
        }

        private RandomizeService RandomizeService { get; }
        private SeedService SeedService { get; }
        private ILogger<SeedController> Logger { get; }

        [Route("/generate")]
        [HttpPost]
        public async Task<ObjectResult> Generate([FromBody] SeedSettings settings) {
            if (!ModelState.IsValid) {
                return BadRequest(ModelState);
            }

            try {
                var id = await this.RandomizeService.RandomizeSeed(settings);
                var url = string.Format("/seed/{0}", id);
                return Accepted(url, id);
            } catch (InvalidSettingsException ex) {
                return BadRequest(ex.Message);
            }
        }

        [Route("/mystery/{randomizer}")]
        [HttpPost]
        public async Task<ObjectResult> RollMystery([FromBody] MysterySettings mysterySettings, RandomizerInstance randomizer, bool race) {
            if (!ModelState.IsValid) {
                return BadRequest(ModelState);
            }

            var baseSettings = new SeedSettings() {
                Randomizer = randomizer,
                Race = race ? RaceMode.Race : RaceMode.Normal,
                Mystery = MysteryMode.Mystery,
            };

            try {
                var id = await this.RandomizeService.RandomizeMystery(mysterySettings, baseSettings);
                var url = string.Format("/seed/{0}", id);
                return Accepted(url, id);
            } catch (InvalidSettingsException ex) {
                return BadRequest(ex.Message);
            }
        }

        [Route("/multiworld")]
        [HttpPost]
        public async Task<ObjectResult> GenerateMultiworld([FromBody] IList<SeedSettings> settings) {
            if (!ModelState.IsValid) {
                return BadRequest(ModelState);
            }
            try {
                var id = await this.RandomizeService.RandomizeMultiworld(settings);
                var url = string.Format("/multi/{0}", id);
                return Accepted(url, id);
            } catch (InvalidSettingsException ex) {
                return BadRequest(ex.Message);
            }
        }

        [Route("/seed/{id}")]
        [HttpGet]
        public async Task<ObjectResult> GetSeed(string id) {
            return ResolveResult(await this.SeedService.GetSeed(id));
        }

        [Route("/seed/{id}")]
        [HttpPost]
        public async Task<ObjectResult> RetrySeed(string id) {
            return ResolveResult(await this.RandomizeService.RetrySeed(id));
        }

        [Route("/multi/{id}")]
        [HttpGet]
        public async Task<ObjectResult> GetMulti(string id) {
            return ResolveResult(await this.SeedService.GetMulti(id));
        }

        [Route("/multi/{id}")]
        [HttpPost]
        public async Task<ObjectResult> RetryMulti(string id) {
            return ResolveResult(await this.RandomizeService.RetryMulti(id));
        }

        [Route("/multidata/{id}")]
        [HttpGet]
        public async Task<ActionResult> GetMultidata(string id) {
            var multidata = await this.SeedService.GetMultidata(id);
            if (multidata == null) {
                return NotFound("multidata not found");
            } else {
                return new FileContentResult(multidata.ToArray(), "application/octet-stream") {
                    FileDownloadName = $"{id}_multidata",
                };
            }
        }

        [Route("/healthcheck")]
        [HttpGet]
        public StatusCodeResult GetHealthCheck() {
            return Ok();
        }

        private ObjectResult ResolveResult(IDictionary<string, object> result) {
            if (result.TryGetValue("status", out var responseCode)) {
                if (responseCode is int code) {
                    return StatusCode(code, result);
                }
            }

            this.Logger.LogWarning("Unexpected result from SeedService: {@Result}", result);
            return StatusCode(500, result);
        }
    }
}
