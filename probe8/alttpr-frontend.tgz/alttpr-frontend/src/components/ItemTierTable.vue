<script>
import { defineComponent } from "vue";

export default defineComponent({});
</script>

<template>
  <table class="table icon-table">
    <thead>
      <tr>
        <th scope="col">Name</th>
        <th scope="col">Map Icon</th>
        <th scope="col">HUD Icon</th>
        <th scope="col">Possible Items</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">Triforce</th>
        <td><img class="map-icon" src="/loot-icons/triforce.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_triforce.png" /></td>
        <td>The Triforce! Instantly wins the game. Not usually placed other than on the pedestal or Ganon, depending on the mode.</td>
      </tr>
      <tr>
        <th scope="row">Triforce Piece</th>
        <td><img class="map-icon" src="/loot-icons/triforce_piece.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_triforce_piece.png" /></td>
        <td>Triforce pieces when the target number of pieces is 100 or less.</td>
      </tr>
      <tr>
        <th scope="row">Crystal</th>
        <td><img class="map-icon" src="/loot-icons/crystal.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_crystal.png" /></td>
        <td>Crystal dungeon prizes, when prizes are shuffled off bosses and collecting crystals is part of the goal.</td>
      </tr>
      <tr>
        <th scope="row">Pendant</th>
        <td><img class="map-icon" src="/loot-icons/pendant.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_pendant.png" /></td>
        <td>Pendant dungeon prizes, when prizes are shuffled off bosses and collecting pendants is part of the goal.</td>
      </tr>
      <tr>
        <th scope="row">Major Item</th>
        <td><img class="map-icon" src="/loot-icons/major_item.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_major_item.png" /></td>
        <td>Swords, Moon Pearl, Flippers, Boots, Gloves, Bomb Bag, and most Y-Items: Bows, Hookshot, Fire Rod, Ice Rod, Bombos, Ether, Quake, Lamp, Hammer, Flute, Book, Cane of Somaria, and Mirror.</td>
      </tr>
      <tr>
        <th scope="row">Big Key</th>
        <td><img class="map-icon" src="/loot-icons/big_key.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_big_key.png" /></td>
        <td>Big Keys.</td>
      </tr>
      <tr>
        <th scope="row">Small Key</th>
        <td><img class="map-icon" src="/loot-icons/small_key.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_small_key.png" /></td>
        <td>Small Keys.</td>
      </tr>
      <tr>
        <th scope="row">Map</th>
        <td><img class="map-icon" src="/loot-icons/map.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_map.png" /></td>
        <td>Dungeon Maps.</td>
      </tr>
      <tr>
        <th scope="row">Compass</th>
        <td><img class="map-icon" src="/loot-icons/compass.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_compass.png" /></td>
        <td>Dungeon Compasses.</td>
      </tr>
      <tr>
        <th scope="row">Minor Item</th>
        <td><img class="map-icon" src="/loot-icons/minor_item.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_minor_item.png" /></td>
        <td>Armor, Progressive Shields, Red Shield, Mirror Shield, Capacity Upgrades, and remaining Y-Items: Boomerangs, Mushroom, Powder, Shovel, Bug Net, Bottles, Cane of Byrna, and Magic Cape. Also includes shuffled dungeon prizes (crystals and pendants) that are not part of the goal.</td>
      </tr>
      <tr>
        <th scope="row">Health</th>
        <td><img class="map-icon" src="/loot-icons/health.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_health.png" /></td>
        <td>Heart Containers, Pieces of Heart, and Potion Refills.</td>
      </tr>
      <tr>
        <th scope="row">Triforce Piece</th>
        <td><img class="map-icon" src="/loot-icons/triforce_piece.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_triforce_piece.png" /></td>
        <td>Triforce pieces when the target number of pieces is more than 100.</td>
      </tr>
      <tr>
        <th scope="row">Universal Key</th>
        <td><img class="map-icon" src="/loot-icons/small_key.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_small_key.png" /></td>
        <td>Small Keys when small key shuffle is set to Universal.</td>
      </tr>
      <tr>
        <th scope="row">Junk</th>
        <td><img class="map-icon" src="/loot-icons/junk.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_junk.png" /></td>
        <td>Heart, bomb, magic, and arrow refills, blue shields, and rupees. Also contains bee traps, bees, apples, fairies, and chickens for mode that include those.</td>
      </tr>
      <tr>
        <th scope="row">Unknown Tier</th>
        <td><img class="map-icon" src="/loot-icons/indicator.png" /></td>
        <td><img class="hud-icon" src="/loot-icons/hud_indicator.png" /></td>
        <td>Shown when the settings do not permit you to see what tier of item is present.</td>
      </tr>
      <tr>
        <th scope="row">NPC Item</th>
        <td></td>
        <td><img class="hud-icon" src="/loot-icons/hud_npc.png" /></td>
        <td>An NPC (Blacksmith, Witch, Sick Kid, Magic Bat, or Sahasrahla) has an unclaimed item which is not otherwise included in the icon in the HUD. All other NPCs' items will show in the main HUD indicator icon.</td>
      </tr>
    </tbody>
  </table>
</template>

<style>
.map-icon {
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
  width: 48px;
  height: 48px;
}

.hud-icon {
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
  width: 24px;
  height: 24px;
  margin-top: 12px;
  margin-bottom: 12px;
}

.icon-table {
  background-color: #DDD !important;
  border-radius: 12px;
  margin-bottom: 0 !important;
}

.icon-table td,th {
  background-color: inherit !important;
}

.icon-table tbody td,th {
  border-bottom: none !important;
}

.icon-table tbody tr:not(:last-child) {
  border-bottom: 1px solid gray;
}

.icon-table thead tr,td,th {
  border-top: none !important;
}

.icon-table thead tr {
  border-bottom: 1px solid gray;
}
</style>
