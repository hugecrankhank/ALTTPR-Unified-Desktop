<script>
import { defineComponent } from "vue";

import settingsData from "@/data/settings-display.yaml";
import mustache from "mustache";

export default defineComponent({
  props: {
    settings: {},
    multi: null,
  },
  computed: {
    settingsDisplay() {
      const rendered = {};
      for (const setting of Object.keys(settingsData)) {
        rendered[setting] = {};
        for (const option of Object.keys(settingsData[setting])) {
          rendered[setting][option] = mustache.render(settingsData[setting][option], this.settings);
        }
      }
      return rendered;
    },
    isEnemizer() {
      return (this.settings.enemy_shuffle && this.settings.enemy_shuffle != "vanilla")
          || (this.settings.boss_shuffle && this.settings.boss_shuffle != "vanilla");
    },
    dungeonItemsShuffled() {
      return (this.settings.small_keys && this.settings.small_keys != "dungeon")
          || (this.settings.big_keys && this.settings.big_keys != "dungeon")
          || (this.settings.maps && this.settings.maps != "dungeon")
          || (this.settings.compasses && this.settings.compasses != "dungeon")
          || (this.settings.prize_shuffle && this.settings.prize_shuffle != "vanilla");
    },
    extraPool() {
      return (this.settings.shop_shuffle && this.settings.shop_shuffle != "vanilla")
          || (this.settings.drop_shuffle && this.settings.drop_shuffle != "vanilla")
          || (this.settings.pot_shuffle && this.settings.pot_shuffle != "vanilla");
    },
    multilink() {
      if (this.multi) {
        return `/multi/${this.multi}`;
      } else {
        return null;
      }
    },
  },
  methods: {
  }
});
</script>

<template>
  <div v-if="multi">
    {{ settings.player_name }} for Multiworld: <router-link :to="multilink">{{ multilink }}</router-link>
    <hr class="mt-2 mb-2" />
  </div>
  <div v-if="settings.randomizer && settingsDisplay.randomizer[settings.randomizer]">
    {{ settingsDisplay.randomizer[settings.randomizer] }}
    <hr class="mt-2 mb-2" />
  </div>
  <template v-if="settings.mystery == 'mystery'">
    <div>
      Mystery Settings
    </div>
  </template>
  <template v-else>
    <div v-if="settings.mode">
      Mode: {{ settingsDisplay.mode[settings.mode] }}
    </div>
    <div v-if="settings.tile_swap && settings.tile_swap != 'vanilla'">
      {{ settingsDisplay.tile_swap[settings.tile_swap] }}
    </div>
    <div v-if="settings.overworld_layout && settings.overworld_layout != 'vanilla'">
      {{ settingsDisplay.overworld_layout[settings.overworld_layout] }}
    </div>
    <div v-if="settings.goal">
      Goal: {{ settingsDisplay.goal[settings.goal] }}
    </div>
    <div v-if="settings.crystals_gt">
      Ganon's Tower Entry: {{ settingsDisplay.crystals_gt[settings.crystals_gt] }}
    </div>
    <div v-if="settings.weapons">
      Weapons: {{ settingsDisplay.weapons[settings.weapons] }}
    </div>
    <div v-if="settings.entrance_shuffle && settings.entrance_shuffle != 'vanilla'">
      <hr class="mt-2 mb-2" />
      <div>
        {{ settingsDisplay.entrance_shuffle[settings.entrance_shuffle] }}
      </div>
    </div>
    <div v-if="settings.door_shuffle && settings.door_shuffle != 'vanilla'">
      <hr class="mt-2 mb-2" />
      <div>
        {{ settingsDisplay.door_shuffle[settings.door_shuffle] }}
      </div>
      <div v-if="settings.lobbies && settings.lobbies != 'vanilla'">
        {{ settingsDisplay.lobbies[settings.lobbies] }}
      </div>
    </div>
    <div v-if="isEnemizer">
      <hr class="mt-2 mb-2" />
      <div v-if="settings.enemy_shuffle && settings.enemy_shuffle != 'vanilla'">
        {{ settingsDisplay.enemy_shuffle[settings.enemy_shuffle] }}
      </div>
      <div v-if="settings.boss_shuffle && settings.boss_shuffle != 'vanilla'">
        {{ settingsDisplay.boss_shuffle[settings.boss_shuffle] }}
      </div>
    </div>
    <div v-if="dungeonItemsShuffled">
      <hr class="mt-2 mb-2" />
      <div v-if="settings.small_keys && settings.small_keys != 'dungeon'">
        {{ settingsDisplay.dungeon_items[settings.small_keys] }} Small Keys
      </div>
      <div v-if="settings.big_keys && settings.big_keys != 'dungeon'">
        {{ settingsDisplay.dungeon_items[settings.big_keys] }} Big Keys
      </div>
      <div v-if="settings.maps && settings.maps != 'dungeon'">
        {{ settingsDisplay.dungeon_items[settings.maps] }} Maps
      </div>
      <div v-if="settings.compasses && settings.compasses != 'dungeon'">
        {{ settingsDisplay.dungeon_items[settings.compasses] }} Compasses
      </div>
      <div v-if="settings.prize_shuffle && settings.prize_shuffle != 'vanilla'">
        {{ settingsDisplay.prize_shuffle[settings.prize_shuffle] }}
      </div>
    </div>
    <div v-if="extraPool">
      <hr class="mt-2 mb-2" />
      <div v-if="settings.shop_shuffle && settings.shop_shuffle != 'vanilla'">
        {{ settingsDisplay.shop_shuffle[settings.shop_shuffle] }}
      </div>
      <div v-if="settings.drop_shuffle && settings.drop_shuffle != 'vanilla'">
        {{ settingsDisplay.drop_shuffle[settings.drop_shuffle] }}
      </div>
      <div v-if="settings.pot_shuffle && settings.pot_shuffle != 'vanilla'">
        {{ settingsDisplay.pot_shuffle[settings.pot_shuffle] }}
      </div>
    </div>
  </template>
</template>
