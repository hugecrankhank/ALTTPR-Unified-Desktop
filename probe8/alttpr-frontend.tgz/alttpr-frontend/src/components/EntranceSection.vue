<script>
import { defineComponent } from "vue";

import spoilerTranslation from "@/data/spoiler-translation.yaml";

export default defineComponent({
  props: {
    label: "",
    entrances: {},
    entrance_arrow: null,
  },
  methods: {
    translate_interior(interior) {
      return spoilerTranslation.entrance_interiors[interior] || interior;
    },
    translate_exterior(exterior) {
      return spoilerTranslation.entrance_exteriors[exterior] || exterior;
    },
  },
});
</script>

<template>
  <template v-if="entrances.length > 0">
    <thead>
      <tr>
        <th colspan="3">{{ label }}:</th>
      </tr>
      <tr>
        <th>Interior:</th>
        <th></th>
        <th>Exterior:</th>
      </tr>
    </thead>
    <tbody>
      <template v-for="entrance in entrances">
        <tr>
          <td>{{ translate_interior(entrance.exit) }}</td>
          <td class="px-3">
            <template v-if="entrance.direction == 'both'">
              <i class="bi bi-arrow-left-right"></i>
            </template>
            <template v-else-if="entrance.direction == 'entrance'">
              <template v-if="entrance_arrow != null">
                <i class="bi" :class="entrance_arrow"></i>
              </template>
              <template v-else>
                <i class="bi bi-arrow-left"></i>
              </template>
            </template>
            <template v-else-if="entrance.direction == 'exit'">
              <i class="bi bi-arrow-right"></i>
            </template>
          </td>
          <td>{{ translate_exterior(entrance.entrance) }}</td>
        </tr>
      </template>
    </tbody>
  </template>
</template>
