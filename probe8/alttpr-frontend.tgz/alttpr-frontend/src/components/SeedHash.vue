<script>
import { defineComponent } from "vue";

import HashIcons from "@/data/hash_icons.yaml";

export default defineComponent({
  props: {
    hash: "",
  },
  computed: {
    icons() {
      const bits = this.hash.split(",").map(bit => bit.trim());
      return bits.map(bit => { return {icon: HashIcons[bit], name: bit} });
    },
  },
});
</script>

<template>
  <div class="inline-block">
    <template v-for="icon in icons">
      <img class="hash_icon" :src="`/hash-icons/${icon.icon}`" :alt="icon.name" />
    </template>
  </div>
</template>

<style>
.hash_icon {
  image-rendering: -moz-crisp-edges;
  image-rendering: crisp-edges;
}
</style>
