<script>
import { defineComponent } from "vue";

import EntranceSection from "@/components/EntranceSection.vue";

import spoilerData from "@/data/spoiler.yaml";

export default defineComponent({
  components: {
    EntranceSection,
  },
  props: {
    entrances: Array,
  },
  computed: {
    mapping() {
      const ret = {};

      for (const entrance of this.entrances) {
        if (!(entrance.exit in ret)) {
          ret[entrance.exit] = {}
        }
        ret[entrance.exit][entrance.direction] = entrance;
      }

      return ret;
    },
    specific() {
      return spoilerData.entrance_categories.dungeons
        .concat(spoilerData.entrance_categories.dropdowns)
        .concat(spoilerData.entrance_categories.connectors)
        .concat(spoilerData.entrance_categories.shops);
    },
    dungeons() {
      return this.filter("dungeons");
    },
    dropdowns() {
      return this.filter("dropdowns");
    },
    connectors() {
      return this.filter("connectors");
    },
    shops() {
      return this.filter("shops");
    },
    other() {
      const ret = [];

      for (const exit of Object.keys(this.mapping)) {
        if (this.specific.includes(exit)) {
          continue;
        }

        const data = this.mapping[exit];
        if (data.both) {
          ret.push(data.both);
        }
        if (data.entrance) {
          ret.push(data.entrance);
        }
        if (data.exit) {
          ret.push(data.exit);
        }
      }

      return ret;
    },
  },
  methods: {
    filter(category) {
      const ret = [];
      for (const exit of spoilerData.entrance_categories[category]) {
        if (exit in this.mapping) {
          const data = this.mapping[exit];
          if (data.both) {
            ret.push(data.both);
          }
          if (data.entrance) {
            ret.push(data.entrance);
          }
          if (data.exit) {
            ret.push(data.exit);
          }
        }
      }
      return ret;
    },
  },
});
</script>

<template>
  <table class="spoiler-table table-striped table-hover">
    <EntranceSection label="Dungeons" :entrances="dungeons" />
    <EntranceSection label="Dropdowns" :entrances="dropdowns" />
    <EntranceSection label="Connectors" :entrances="connectors" />

    <EntranceSection label="Shops" :entrances="shops" entrance_arrow="bi-arrow-left-right" />
    <EntranceSection label="Other" :entrances="other" entrance_arrow="bi-arrow-left-right" />
  </table>
</template>
