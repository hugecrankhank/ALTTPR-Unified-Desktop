<script>
import { defineComponent } from "vue";

export default defineComponent({
  props: {
    name: "",
  },
});
</script>

<template>
  <div class="card mb-3 setting-info-card">
    <div class="card-header">
      <b>{{ name }}</b>
    </div>
    <div class="m-3">
      <slot></slot>
    </div>
  </div>
</template>

<style>
.setting-info-card p:last-child {
  margin-bottom: 0;
}
</style>
