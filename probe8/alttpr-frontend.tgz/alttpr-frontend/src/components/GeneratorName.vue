<script>
import { defineComponent } from "vue";

import settingsDisplay from "@/data/settings-display.yaml";

export default defineComponent({
  props: {
    generator: "",
  },
  computed: {
    display() {
      return settingsDisplay.randomizer_generator[this.generator];
    }
  },
});
</script>

<template>
  <span v-if="display">
    {{ display }}
  </span>
</template>
