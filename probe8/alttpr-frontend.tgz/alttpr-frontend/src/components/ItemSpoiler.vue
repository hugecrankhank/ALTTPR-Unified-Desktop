<script>
import { defineComponent } from "vue";

import spoilerData from "@/data/spoiler.yaml";

export default defineComponent({
  props: {
    spoiler: {},
    category: {},
    player_name: null,
  },
  computed: {
    item_locations() {
      const ret = {}
      for (const category of Object.keys(this.spoiler)) {
        var found = false;
        for (const categoryPrefix of spoilerData.item_sections) {
          if (category.startsWith(categoryPrefix)) {
            found = true;
            break;
          }
        }

        if (!found) {
          continue;
        }

        const list = this.spoiler[category];
        for (const loc of Object.keys(list)) {
          ret[loc] = list[loc];
        }
      }

      return ret;
    },
    suffix() {
      if (this.player_name) {
        return ` (${this.player_name})`;
      } else {
        return "";
      }
    },
    item_mappings() {
      const ret = {}
      for (const item of this.category.items) {
        ret[item + this.suffix] = { display: item, locations: [] };
      }

      for (const loc of Object.keys(this.item_locations)) {
        const item = this.item_locations[loc];
        if (item in ret) {
          ret[item].locations.push(loc);
        }
      }

      return ret;
    },
  },
});
</script>

<template>
  <table class="spoiler-table table-striped table-hover">
    <thead>
      <tr>
        <th colspan="2">{{ category.display }}:</th>
      </tr>
    </thead>
    <tbody>
      <template v-for="(data) in item_mappings">
        <template v-if="data.locations.length > 0">
          <tr>
            <td>{{ data.display }}</td>
            <td>
              <template v-for="location in data.locations">
                {{ location }}<br>
              </template>
            </td>
          </tr>
        </template>
      </template>
    </tbody>
  </table>
</template>
