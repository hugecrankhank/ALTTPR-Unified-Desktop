<script>
import { defineComponent } from "vue";

export default defineComponent({
  props: {
    spoiler: {},
  },
});
</script>

<template>
  <table class="spoiler-table table-striped table-hover">
    <template v-for="(items, sphere) in spoiler.playthrough">
      <template v-if="sphere == '0' && items.length > 0">
        <thead>
          <tr>
            <th colspan="2">Starting Items:</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, location) in items">
            <td></td>
            <td>{{ item }}</td>
          </tr>
        </tbody>
      </template>
      <template v-if="sphere != '0'">
        <thead>
          <tr>
            <th colspan="2">Sphere {{ sphere }}:</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, location) in items">
            <td>{{ location }}</td>
            <td>{{ item }}</td>
          </tr>
        </tbody>
      </template>
    </template>
  </table>
</template>
