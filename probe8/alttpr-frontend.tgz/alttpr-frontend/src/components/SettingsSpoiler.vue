<script>
import { defineComponent } from "vue";

import settingsData from "@/data/settings.yaml";
import mustache from "mustache";

export default defineComponent({
  props: {
    settings: {},
  },
  computed: {
    settingsDisplay() {
      const rendered = {};

      for (const setting of Object.keys(this.settings)) {
        const data = settingsData[setting];
        const nameDisplay = data?.display || setting;
        const value = this.settings[setting];
        const valueDisplay = data?.values && data.values[value]?.display || value;
        if (valueDisplay) {
          rendered[nameDisplay] = valueDisplay;
        }
      }
      return rendered;
    },
  },
});
</script>

<template>
  <table class="spoiler-table table-striped table-hover">
    <thead>
      <tr>
        <th colspan="2">Settings:</th>
      </tr>
    </thead>
    <tbody>
      <template v-for="(value, setting) in settingsDisplay">
        <tr>
          <td>{{ setting }}</td>
          <td>{{ value }}</td>
        </tr>
      </template>
    </tbody>
  </table>
</template>
