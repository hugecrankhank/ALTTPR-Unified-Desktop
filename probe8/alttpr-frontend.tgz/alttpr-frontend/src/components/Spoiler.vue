<script>
import { defineComponent } from "vue";

import SettingsSpoiler from "@/components/SettingsSpoiler.vue";
import PlaythroughSpoiler from "@/components/PlaythroughSpoiler.vue";
import ItemSpoiler from "@/components/ItemSpoiler.vue";
import EntranceSpoiler from "@/components/EntranceSpoiler.vue";

import spoilerData from "@/data/spoiler.yaml";

export default defineComponent({
  components: {
    SettingsSpoiler,
    PlaythroughSpoiler,
    ItemSpoiler,
    EntranceSpoiler,
  },
  props: {
    settings: {},
    spoiler: {},
  },
  computed: {
    item_categories() {
      return spoilerData.item_categories;
    },
    player_slot() {
      if (this.settings.player_slot) {
        return this.settings.player_slot;
      }

      return null;
    },
    entrances() {
      if (!this.player_slot) {
        return this.spoiler.Entrances;
      }

      return this.spoiler.Entrances.filter(ent => !ent.player || ent.player == this.player_slot);
    },
  },
});
</script>

<template>
  <div class="card content-div m-3">
    <ul class="nav nav-tabs ps-3 pt-3 pe-3">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" type="button" role="tab" ref="tabs"
            data-bs-toggle="tab" data-bs-target="#settings">
          Settings
        </button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" type="button" role="tab" ref="tabs"
            data-bs-toggle="tab" data-bs-target="#playthrough">
          Playthrough
        </button>
      </li>
      <li class="nav-item" role="presentation" v-for="(category, idx) in item_categories">
        <button class="nav-link" type="button" role="tab" ref="tabs"
            data-bs-toggle="tab" :data-bs-target="`#category_${idx}`">
          {{ category.display }}
        </button>
      </li>
      <li class="nav-item" role="presentation" v-if="entrances.length > 1">
        <button class="nav-link" type="button" role="tab" ref="tabs"
            data-bs-toggle="tab" data-bs-target="#entrances">
          Entrances
        </button>
      </li>
    </ul>
    <div class="px-4 tab-content">
      <div id="settings" class="tab-pane active show" role="tabpanel">
        <SettingsSpoiler :settings="settings" />
      </div>
      <div id="playthrough" class="tab-pane" role="tabpanel">
        <PlaythroughSpoiler :spoiler="spoiler" />
      </div>
      <template v-for="(category, idx) in item_categories">
        <div :id="`category_${idx}`" class="tab-pane" role="tabpanel">
          <ItemSpoiler :spoiler="spoiler" :category="category" :player_name="settings.player_name" />
        </div>
      </template>
      <div id="entrances" class="tab-pane" role="tabpanel">
        <EntranceSpoiler :entrances="entrances" />
      </div>
    </div>
  </div>
</template>
