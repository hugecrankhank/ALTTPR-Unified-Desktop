<script>
import { defineComponent } from "vue";
import { Collapse } from "bootstrap";

export default defineComponent({
  data() {
    return {
      navbar: null,
    };
  },
  async mounted() {
    this.navbar = Collapse.getOrCreateInstance(this.$refs.navbar, {toggle: false});
  },
  methods: {
    collapse() {
      this.navbar.hide();
    },
  },
});
</script>

<template>
  <nav class="navbar navbar-expand-sm bg-dark-subtle pt-1 px-2">
    <div class="container-fluid px-1">
      <a class="navbar-brand ps-1 py-0 me-2">
        <img class="brand-logo" src="/gwaa_logo.png" />
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle Navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div id="navbar" class="collapse navbar-collapse" ref="navbar">
        <ul class="navbar-nav center">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Seed
            </a>
            <ul class="dropdown-menu">
              <li>
                <router-link to="/generate" class="dropdown-item" @click="collapse">
                  Base Randomizer
                </router-link>
              </li>
              <li>
                <router-link to="/generate/beta" class="dropdown-item" @click="collapse">
                  Beta Randomizer
                </router-link>
              </li>
              <li>
                <router-link to="/generate/apr2025" class="dropdown-item" @click="collapse">
                  April 2025 Randomizer
                </router-link>
              </li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Multiworld
            </a>
            <ul class="dropdown-menu">
              <li>
                <router-link to="/multiworld" class="dropdown-item" @click="collapse">
                  Base Randomizer
                </router-link>
              </li>
              <li>
                <router-link to="/multiworld/beta" class="dropdown-item" @click="collapse">
                  Beta Randomizer
                </router-link>
              </li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Mystery
            </a>
            <ul class="dropdown-menu">
              <li>
                <router-link to="/mystery" class="dropdown-item" @click="collapse">
                  Base Randomizer
                </router-link>
              </li>
              <li>
                <router-link to="/mystery/beta" class="dropdown-item" @click="collapse">
                  Beta Randomizer
                </router-link>
              </li>
            </ul>
          </li>
          <li class="nav-item nav-link">
            <router-link to="/settings">
              Settings Help
            </router-link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<style>
.brand-logo {
  height: 28px;
}
</style>
