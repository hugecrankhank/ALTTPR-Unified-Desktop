<script>
import { defineComponent } from "vue";

import AccordionItem from "@/components/AccordionItem.vue";
import SettingInfoCard from "@/components/SettingInfoCard.vue";
import ItemTierTable from "@/components/ItemTierTable.vue";

export default defineComponent({
  components: {
    AccordionItem,
    SettingInfoCard,
    ItemTierTable,
  },
  mounted() {
    document.title = "ALttPRandomizer Seed Settings"
  },
});
</script>

<template>
  <div class="mw-60">
    <div class="card content-div m-3">
      <div class="card-header text-center">
        Seed Options
      </div>
      <div id="settings" class="accordion accordion-flush">
        <AccordionItem :expanded="true">
          <template #header>
            <b>Map and HUD Settings</b>
          </template>

          <SettingInfoCard name="Show Dungeon Maps">
            <p>This setting controls how the dungeon map will display rooms within a dungeon:</p>
            <ul>
              <li><b>Visited Tiles Only:</b> Unvisited tiles will be shown as undetailed blue squares; tiles that have been visited at least once will display as a rough outline of the room(s) with some features marked.</li>
              <li><b>Visited + Map:</b> Same as above, but unvisited tiles are also shown as rough outlines within dungeons for which the player has obtained the dungeon map.</li>
              <li><b>Always:</b> All tiles are shown as outlines of the contained room(s).</li>
            </ul>
            Note: Regardless of setting, quadrants of tiles that have been visited will be displayed in a lighter blue color than quadrants that have not been visited.
          </SettingInfoCard>

          <SettingInfoCard name="Show Dungeon Checks on Map">
            <p>This setting controls how icons for uncollected checks on the dungeon map will be displayed:</p>
            <ul>
              <li><b>Never:</b> No icons will be displayed on the dungeon map for uncollected checks.</li>
              <li><b>Uncollected:</b> A dot icon will show on the dungeon map on every tile with at least one uncollected check.</li>
              <li><b>Value With Compass:</b> For dungeons in which the player has the compass, an icon will show on the dungeon map in every tile with at least one uncollected check. The displayed icon depends on the highest tier of uncollected item within that tile (see below for details). In dungeons where the player does not have the compass, tiles with uncollected checks will show either a compass icon if there is a compass in that tile, or a dot if none of the remaining checks in that tile are compasses.</li>
              <li><b>Value Always:</b> An icon will show on the dungeon map in every tile with at least one uncollected check. The displayed icon depends on the highest tier of uncollected item within that tile (see below for details).</li>
            </ul>
            Note: Regardless of setting, a skull icon will be displayed on the dungeon map in the room with the boss if the player has the compass for that dungeon.
          </SettingInfoCard>

          <SettingInfoCard name="Show Underworld Checks on HUD">
            <p>This setting controls how icons for uncollected checks on the current underworld tile will be displayed on the HUD:</p>
            <ul>
              <li><b>Never:</b> No icon will be displayed on the HUD for uncollected checks. If enemy drop shuffle is set to "All Underworld Enemies", a blue square will appear in the HUD when there is at least one enemy whose drop has not yet been obtained.</li>
              <li><b>Uncollected:</b> A dot icon will show on the HUD when there is at least one uncollected check in the current tile. Additionally, a speech bubble will show where there is an NPC on the current tile with a turn-in that has not been obtained.</li> 
              <li><b>Value:</b> An icon will show on the HUD where there is at least one uncollected check in the current tile. The displayed icon depends on the highest tier of uncollected item within that tile (see below for details).</li>
              <li><b>Value in Dungeons, Presence in Caves:</b> An icon will show on the HUD where there is at least one uncollected check in the current tile. In non-dungeon underworld areas, the icon will simply be a dot; in dungeons, the displayed icon depends on the highest tier of uncollected item within that tile (see below for details).</li>
              <li><b>Value in Caves, Presence in Dungeons:</b> An icon will show on the HUD where there is at least one uncollected check in the current tile. In dungeons, the icon will simply be a dot; in other underworld tiles, the displayed icon depends on the highest tier of uncollected item within that tile (see below for details).</li>
            </ul>
            Note: For any setting other than "Never", a speech bubble will additionally appear in tiles where there is an NPC on the current tile with a turn-in that has not been obtained. (This applies to Magic Bat, Sick Kid, Sahasrahla, the Potion Shop, and the Blacksmith.)
          </SettingInfoCard>

          <SettingInfoCard name="Iconography">
            <ItemTierTable />
          </SettingInfoCard>
        </AccordionItem>
      </div>
    </div>
  </div>
</template>
