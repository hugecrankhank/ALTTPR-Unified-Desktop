<script>
import { defineComponent } from "vue";

import AccordionItem from "@/components/AccordionItem.vue";
import SettingInfoCard from "@/components/SettingInfoCard.vue";
import ItemTierTable from "@/components/ItemTierTable.vue";

export default defineComponent({
  components: {
    SettingInfoCard,
    ItemTierTable,
  },
  mounted() {
    document.title = "10-Year Walk Through Time Settings"
  },
});
</script>

<template>
  <div class="mw-60">
    <div class="card content-div m-3">
      <div class="card-header text-center">
        <b>10-Year Anniversary Walk-Through-Time Settings</b>
      </div>
      <div class="p-3">
        <SettingInfoCard name="Pseudoboots">
          <p>Link is equipped with boots that will allow him to dash, but not bonk open any entrances or knock things off of high places until he collects the real boots.</p>
        </SettingInfoCard>
        <SettingInfoCard name="Pseudoflute">
          <p>Link is equipped with a basic flute that will allow him to travel via duck to any flute spot on a screen he has visited, with the exception of the flute spot in the desert, which will not be unlocked until the real flute is collected. Upon collecting the real flute, it will be immediately active and all spots will be unlocked regardless of whether Link has visited the screen.</p>
        </SettingInfoCard>
        <SettingInfoCard name="Book can Flip Crystal Switches">
          <p>Using the Book of Mudora while indoors will flip the state of the red and blue pegs, as if Link had hit a crystal switch.</p>
        </SettingInfoCard>
        <SettingInfoCard name="Free Light Cone in Dark Rooms">
          <p>Link does not need the Lamp to be able to see in dark rooms, and will always get a cone of light while in a dark room. This is logically accounted for, which can change some rules you are used to about when dark rooms are in logic...</p>
        </SettingInfoCard>
        <SettingInfoCard name="Goal: BossHunt">
          <p>Link's goal is to defeat at least 10 of the 12 dungeon bosses (the 10 main dungeon prize bosses plus both forms of Agahnim, but not the three mini-bosses in Ganon's Tower) and then defeat Ganon. The item select screen will show an icon indicating what bosses you have defeated in the same table as your list of keys and other dungeon items. Collecting crystals and pendants is not necessarily required, but the two red crystals are still required to obtain the big bomb, and pendants are required for Sahasrahla and the pedestal item as usual. Ganon's Tower will start unlocked, so no crystals are needed for that.</p>
        </SettingInfoCard>
        <SettingInfoCard name="Ganon's Weakness: Bee Required">
          <p>Ganon has managed to protect himself from silver and well-timed sword attacks, but at a new cost: an allergy to beestings. Once Ganon is stunned as usual during phase 4, you will need to release a bee to hurt Ganon instead of using silver arrows...</p>
          <p>One bee should last long enough to defeat Ganon, and you will be unable to damage Ganon in phase 4 during the frames in which he raises his arms (or in any other way).</p>
          <p>Bees can be caught with the bug net from under various bushes throughout Hyrule or retrieved from the statue in the cave near the Ice Rod's vanilla location; or without a bug net, can be purchased from the Red Shield Shop in the dark world.</p>
        </SettingInfoCard>
        <SettingInfoCard name="Loot Icons">
          <p>Finally, inside dungeons, there will be upgraded dungeon maps. On each tile, there will be an icon representing the highest-tier uncollected check on that tile. You can also use L and R to switch between viewing the maps of any dungeons that you have visited. Note that the front of Hyrule Castle and the back/sewer area are displayed on separate maps, but as you long as you have visited either you can view either at any time.</p>
          <p>Likewise, in all underworld areas, there will also be an icon on the HUD indicating the highest-tier uncollected check in your current tile.</p>
          <p>The follow tables lists the tiers of item checks you may see. Note that since prizes are guaranteed to be on the boss, dungeon prizes (crystals/pendants) will <i>not</i> show up in the iconography.</p>
          <ItemTierTable />
        </SettingInfoCard>
      </div>
    </div>
  </div>
</template>
