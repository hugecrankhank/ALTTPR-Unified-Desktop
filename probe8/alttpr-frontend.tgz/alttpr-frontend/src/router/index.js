import { createRouter, createWebHistory } from "vue-router";
import SeedView from "@/views/SeedView.vue";
import MultiView from "@/views/MultiView.vue";
import GenerateView from "@/views/GenerateView.vue";
import GenerateMulti from "@/views/GenerateMulti.vue";
import GenerateMystery from "@/views/GenerateMystery.vue";
import GenerateApr2025View from "@/views/GenerateApr2025View.vue";
import SettingsHelp from "@/views/SettingsHelp.vue";
import WTTSettings from "@/views/WTTSettings.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/generate",
      name: "generate",
      component: GenerateView,
      alias: "/",
      props: { generator: "base", prefix: "" },
    },
    {
      path: "/multiworld",
      name: "multiworld",
      component: GenerateMulti,
      alias: "/multi",
      props: { generator: "base", prefix: "" },
    },
    {
      path: "/generate/apr2025",
      component: GenerateApr2025View,
    },
    {
      path: "/generate/beta",
      component: GenerateView,
      alias: "/generate/beta_test",
      props: { generator: "beta", prefix: "dungeon-maps-" },
    },
    {
      path: "/generate/pikit",
      component: GenerateView,
      props: { generator: "pikit", prefix: "pikit-" },
    },
    {
      path: "/multiworld/beta",
      component: GenerateMulti,
      alias: "/multibeta",
      props: { generator: "beta", prefix: "dungeon-maps-" },
    },
    {
      path: "/mystery",
      component: GenerateMystery,
      props: { generator: "base", prefix: "" },
    },
    {
      path: "/mystery/beta",
      component: GenerateMystery,
      props: { generator: "beta", prefix: "beta-" },
    },
    {
      path: "/seed/:id",
      name: "seed",
      component: SeedView,
    },
    {
      path: "/multi/:id",
      name: "multi",
      component: MultiView,
    },
    {
      path: '/settings',
      name: "settings",
      component: SettingsHelp,
    },
    {
      path: '/10year',
      component: WTTSettings,
    },
  ],
});

export default router;
