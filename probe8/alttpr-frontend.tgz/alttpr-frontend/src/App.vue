<script>
import { defineComponent } from "vue";
import { RouterView } from "vue-router";

import NavBar from "@/components/NavBar.vue";

export default defineComponent({
  components: {
    NavBar,
  }
});
</script>

<template>
  <header>
    <div class="wrapper">
    </div>
  </header>

  <NavBar />

  <RouterView />
</template>

<style scoped>
</style>
