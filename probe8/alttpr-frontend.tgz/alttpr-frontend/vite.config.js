import { fileURLToPath, URL } from 'node:url'

import { defineConfig, loadEnv } from "vite";
import vue from "@vitejs/plugin-vue";
import { yamlPlugin } from "vite-yaml-plugin";
import vueDevTools from "vite-plugin-vue-devtools";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  return {
    define: {
      BACKEND_URL: JSON.stringify(env.BACKEND_URL),
    },
    server: {
      port: 8082,
    },
    plugins: [
      vue(),
      yamlPlugin(),
      vueDevTools(),
    ],
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url))
      },
    },
  };
});
